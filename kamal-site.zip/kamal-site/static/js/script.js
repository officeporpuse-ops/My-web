// Reveal on scroll
const revealElements = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('active');
    });
}, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
revealElements.forEach(el => revealObserver.observe(el));

// Mobile menu
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mobileMenuClose = document.getElementById('mobileMenuClose');
const mobileMenu = document.getElementById('mobileMenu');
const mobileLinks = document.querySelectorAll('.mobile-link');

mobileMenuBtn.addEventListener('click', () => mobileMenu.classList.add('open'));
mobileMenuClose.addEventListener('click', () => mobileMenu.classList.remove('open'));
mobileLinks.forEach(link => {
    link.addEventListener('click', () => mobileMenu.classList.remove('open'));
});

// Contact form -> real POST to Flask backend
const contactForm = document.getElementById('contactForm');
const formSuccess = document.getElementById('formSuccess');
const formError = document.getElementById('formError');

contactForm.addEventListener('submit', async function (e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const label = btn.querySelector('.btn-label');
    const originalLabel = label.textContent;

    btn.disabled = true;
    label.textContent = 'Sending...';
    formError.classList.add('hidden');

    try {
        const formData = new FormData(this);
        const response = await fetch('/contact', { method: 'POST', body: formData });
        const data = await response.json();

        if (data.ok) {
            formSuccess.classList.remove('hidden');
            this.reset();
            setTimeout(() => formSuccess.classList.add('hidden'), 4000);
        } else {
            formError.textContent = data.error || 'Something went wrong. Please try again.';
            formError.classList.remove('hidden');
        }
    } catch (err) {
        formError.textContent = 'Could not reach the server. Please try again.';
        formError.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        label.textContent = originalLabel;
    }
});

// Back to top
const backToTop = document.getElementById('backToTop');
window.addEventListener('scroll', () => {
    backToTop.classList.toggle('visible', window.scrollY > 500);
});
backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

// Active nav link highlight
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-links a[href^="#"]');
window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        if (window.scrollY >= sectionTop) current = section.getAttribute('id');
    });
    navLinks.forEach(link => {
        link.classList.toggle('active-link', link.getAttribute('href') === '#' + current);
    });
});
