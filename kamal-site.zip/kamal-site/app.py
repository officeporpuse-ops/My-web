"""
Kamal Abbas — Personal Website
Built with Flask + Jinja2. All page content lives in data/content.py
as plain Python data structures, so editing your info means editing
one Python file — no touching HTML.
"""

import json
import os
from datetime import datetime

from flask import Flask, render_template, request, jsonify

from data.content import PROFILE, STATS, EDUCATION, SKILLS, GALLERY, COLLEAGUE, SOCIAL_LINKS

app = Flask(__name__)

MESSAGES_FILE = os.path.join(os.path.dirname(__file__), "data", "messages.json")


@app.route("/")
def home():
    return render_template(
        "index.html",
        profile=PROFILE,
        stats=STATS,
        education=EDUCATION,
        skills=SKILLS,
        gallery=GALLERY,
        colleague=COLLEAGUE,
        social=SOCIAL_LINKS,
        year=datetime.now().year,
    )


@app.route("/contact", methods=["POST"])
def contact():
    """
    Handles the contact form. Since sending real email requires an
    SMTP provider (Gmail app password, SendGrid, etc.), this saves
    submissions to data/messages.json so nothing is silently lost.
    Swap the save step for an SMTP call once you have credentials —
    see the README.
    """
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    message = request.form.get("message", "").strip()

    if not name or not email or not message:
        return jsonify({"ok": False, "error": "All fields are required."}), 400

    entry = {
        "name": name,
        "email": email,
        "message": message,
        "received_at": datetime.now().isoformat(timespec="seconds"),
    }

    existing = []
    if os.path.exists(MESSAGES_FILE):
        with open(MESSAGES_FILE, "r", encoding="utf-8") as f:
            try:
                existing = json.load(f)
            except json.JSONDecodeError:
                existing = []

    existing.append(entry)

    with open(MESSAGES_FILE, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2, ensure_ascii=False)

    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
