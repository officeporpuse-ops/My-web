"""
Every piece of text, image, and section on the website lives here.
Edit this file to change your bio, add education entries, add skills,
swap photos, etc. — the template (templates/index.html) never needs
to change for content updates.
"""

PROFILE = {
    "name": "Kamal Abbas",
    "tagline": "Developer · Problem Solver · Mountain Soul",
    "intro": (
        "From the breathtaking mountains of Gilgit-Baltistan to the "
        "dynamic city of Karachi — building the future through code."
    ),
    "photo": (
        "https://z-cdn-media.chatglm.cn/files/8980d89e-0cba-4d1c-aa3f-8ec167766d6f.png"
        "?auth_key=1884418802-1d69476eaccf407b9d54a373b83341d8-0-5e7ed22ed115b9bb7cc209f990cfbd21"
    ),
    "about_paragraphs": [
        "I'm <strong>Kamal Abbas</strong>, originally from the breathtaking region of "
        "<strong>Gilgit-Baltistan</strong>. Nestled among towering mountains and stunning "
        "landscapes, Gilgit-Baltistan is truly a paradise on Earth, and I can't wait to "
        "share a glimpse of it with you.",
        "A little about my journey: I completed my matriculation in 2022, then moved to "
        "Rawalpindi for my intermediate studies, which I completed in 2024 with a focus on "
        "Mathematics. Now I'm currently in Karachi, diving deeper into my education and "
        "developing my skills in programming.",
    ],
    "quick_info": [
        {"label": "Location", "value": "Karachi, Pakistan", "icon": "lucide:map-pin"},
        {"label": "Origin", "value": "Gilgit-Baltistan", "icon": "lucide:mountain"},
        {"label": "Focus", "value": "Mathematics", "icon": "lucide:calculator"},
        {"label": "Passion", "value": "Programming", "icon": "lucide:terminal"},
    ],
    "location": "Karachi, Pakistan",
    "origin": "Gilgit-Baltistan, Pakistan",
    "email": "kamalabbas@email.com",
    "quote": (
        "From the mountains of <span class='text-red-400'>Gilgit</span> to the code editors "
        "of <span class='text-red-400'>Karachi</span> — every line of code is a step toward "
        "the future."
    ),
}

STATS = [
    {"value": "2022", "label": "Matriculated"},
    {"value": "2024", "label": "Intermediate"},
    {"value": "3+", "label": "Cities Lived"},
    {"value": "∞", "label": "Passion for Code"},
]

EDUCATION = [
    {
        "year": "2022",
        "title": "Matriculation",
        "description": (
            "Completed my matriculation from Gilgit-Baltistan, building a strong academic "
            "foundation amidst the stunning mountain scenery that shaped my early perspective."
        ),
        "tag": "Science Group",
        "icon": "lucide:graduation-cap",
    },
    {
        "year": "2022 — 2024",
        "title": "Intermediate (FSc)",
        "description": (
            "Moved to Rawalpindi for intermediate studies with a focus on Mathematics. "
            "This period taught me independence, adaptability, and deepened my analytical thinking."
        ),
        "tag": "Pre-Engineering / Mathematics",
        "icon": "lucide:calculator",
    },
    {
        "year": "2024 — Present",
        "title": "Programming & CS",
        "description": (
            "Currently in Karachi, diving deeper into education and developing programming "
            "skills. Embracing the fast-paced urban environment while building my future in tech."
        ),
        "tag": "Computer Science & Development",
        "icon": "lucide:code-2",
    },
]

SKILLS = [
    {
        "title": "Programming",
        "description": (
            "Building logic and problem-solving skills through hands-on coding projects "
            "and algorithmic thinking."
        ),
        "icon": "lucide:code-2",
        "tags": ["Python", "JavaScript", "HTML/CSS"],
    },
    {
        "title": "Mathematics",
        "description": (
            "Strong foundation in mathematical reasoning, calculus, and algebra — the "
            "backbone of computational thinking."
        ),
        "icon": "lucide:brain",
        "tags": ["Calculus", "Algebra", "Statistics"],
    },
    {
        "title": "Web Development",
        "description": (
            "Crafting responsive, modern web experiences with clean design and efficient, "
            "maintainable code."
        ),
        "icon": "lucide:globe",
        "tags": ["Flask", "Tailwind", "Jinja2"],
    },
    {
        "title": "Databases",
        "description": (
            "Understanding data structures, queries, and efficient storage solutions for "
            "modern applications."
        ),
        "icon": "lucide:database",
        "tags": ["SQL", "MongoDB"],
    },
    {
        "title": "Version Control",
        "description": (
            "Collaborative development using Git workflows, branching strategies, and code "
            "review processes."
        ),
        "icon": "lucide:git-branch",
        "tags": ["Git", "GitHub"],
    },
    {
        "title": "Languages",
        "description": (
            "Multilingual communication skills, bridging cultures and connecting with "
            "diverse communities."
        ),
        "icon": "lucide:languages",
        "tags": ["Urdu", "English", "Shina"],
    },
]

GALLERY = [
    {
        "title": "Karakoram Range",
        "caption": "Home to K2, the second highest peak",
        "image": "https://picsum.photos/seed/karakoram-peaks/800/500.jpg",
    },
    {
        "title": "Hunza Valley",
        "caption": "The paradise on Earth",
        "image": "https://picsum.photos/seed/hunza-valley-lake/800/500.jpg",
    },
    {
        "title": "Glaciers",
        "caption": "Ancient rivers of ice and time",
        "image": "https://picsum.photos/seed/glacier-pakistan/800/500.jpg",
    },
    {
        "title": "Attabad Lake",
        "caption": "Turquoise gem in the mountains",
        "image": "https://picsum.photos/seed/attabad-lake-blue/800/500.jpg",
    },
]

COLLEAGUE = {
    "name": "Sikander Shah",
    "role": "Chief Executive Officer",
    "tags": ["CEO", "Classmate"],
    "photo": (
        "https://z-cdn-media.chatglm.cn/files/40ac87c3-6845-4c1b-b094-072309ce242a.png"
        "?auth_key=1884418802-9ad964239df742c4bf11331a345277ae-0-ca2d2d1b0061795d912340673aa53285"
    ),
    "paragraphs": [
        "Sikander Shah is not just my CEO — he's a former classmate who has consistently "
        "demonstrated excellence in his work. His leadership is defined by a deep "
        "understanding of technology, strategic thinking, and an unwavering commitment "
        "to quality.",
        "From our classroom days to the professional world, Sikander has always stood out "
        "for his dedication, innovative mindset, and ability to turn ideas into reality. "
        "He leads by example and inspires everyone around him to push their limits.",
    ],
    "traits": [
        {"label": "Entrepreneur", "icon": "lucide:briefcase"},
        {"label": "Exceptional Leader", "icon": "lucide:award"},
        {"label": "Visionary", "icon": "lucide:heart"},
    ],
}

SOCIAL_LINKS = [
    {"label": "GitHub", "icon": "lucide:github", "url": "#"},
    {"label": "LinkedIn", "icon": "lucide:linkedin", "url": "#"},
    {"label": "Twitter", "icon": "lucide:twitter", "url": "#"},
    {"label": "Instagram", "icon": "lucide:instagram", "url": "#"},
]
