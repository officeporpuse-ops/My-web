# Kamal Abbas — Personal Website (Python / Flask)

A rebuild of your portfolio site using Python (Flask + Jinja2) instead of
a single static HTML file. All your content — bio, education, skills,
gallery, colleague info — lives in `data/content.py` as plain Python
data. Edit that file to update the site; you never need to touch HTML.

## Project structure

```
kamal-site/
├── app.py                 # Flask app: routes + contact form handler
├── data/
│   └── content.py         # ALL your content — edit this to update the site
├── templates/
│   └── index.html         # Jinja2 template (loops over data/content.py)
├── static/
│   ├── css/style.css      # Plain CSS (converted from the original Tailwind)
│   └── js/script.js       # Scroll reveals, mobile menu, contact form fetch()
└── requirements.txt
```

## How to run it

1. Install Python 3.9+ if you don't have it.
2. Install Flask:
   ```
   pip install -r requirements.txt
   ```
3. Run the server:
   ```
   python app.py
   ```
4. Open **http://localhost:5000** in your browser.

## Editing your info

Open `data/content.py`. Everything is a Python dict or list:

- `PROFILE` — your name, tagline, bio paragraphs, quick-info cards, quote
- `STATS` — the four numbers in the stats bar
- `EDUCATION` — the timeline items (add/remove entries freely)
- `SKILLS` — the skill cards
- `GALLERY` — the Gilgit-Baltistan photo section
- `COLLEAGUE` — the Sikander Shah section
- `SOCIAL_LINKS` — GitHub/LinkedIn/etc URLs (currently `#` — fill these in)

Adding a new education entry, for example, is just adding a new
dictionary to the `EDUCATION` list — the template automatically renders it.

## About the contact form

The form does a real `fetch()` POST to `/contact` on your Flask server.
Right now it **saves each message to `data/messages.json`** rather than
emailing you, because actually sending email requires SMTP credentials
(a Gmail app password, SendGrid API key, etc.) that only you can provide.

To make it send you a real email instead, in `app.py`'s `contact()`
function, replace the "save to messages.json" block with something like:

```python
import smtplib
from email.mime.text import MIMEText

msg = MIMEText(f"From: {name} <{email}>\n\n{message}")
msg["Subject"] = "New message from your website"
msg["From"] = "your-site@example.com"
msg["To"] = "kamalabbas@email.com"

with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
    server.login("your-site@example.com", "your-app-password")
    server.send_message(msg)
```

## Notes on images

Your photo and Sikander's photo are currently pulled from the
`z-cdn-media.chatglm.cn` links you already had — those work as long as
that link stays live. For a permanent site, download those images and
put them in a new `static/images/` folder, then update the `photo`
field in `data/content.py` to `/static/images/yourphoto.png`.

The four homeland photos are still placeholder stock images
(`picsum.photos`) — swap in real photos of Gilgit-Baltistan the same way.

## Deploying it for real (so it's a live website)

Right now this only runs on your own machine. To make it a real,
publicly reachable website, you'd deploy it to a host that runs Python,
e.g. **Render**, **Railway**, or **PythonAnywhere** (all have free
tiers) — each just needs your `requirements.txt` and `app.py` to know
how to start the server.
